<?php
// require_once('PHPMailer/PHPMailer.php');
// require_once('PHPMailer/SMTP.php');
// require_once('PHPMailer/Exception.php');
 
// use PHPMailer\PHPMailer\PHPMailer;
// use PHPMailer\PHPMailer\SMTP;
// use PHPMailer\PHPMailer\Exception;

function amille_party_load_scripts()
{
    
    wp_enqueue_style('bootstrap', get_template_directory_uri().'/assets/css/bootstrap.min.css', array(), '1.0', 'all');
    wp_enqueue_style('glider', get_template_directory_uri().'/assets/css/glider.min.css', array('bootstrap'), '1.0', 'all');
    wp_enqueue_style('main', get_template_directory_uri().'/assets/css/main.css', array('bootstrap'), '1.0', 'all');
    wp_enqueue_style('home', get_template_directory_uri().'/assets/css/home.css', array('main'), '1.0', 'all');
    wp_register_style('confirm-presence', get_template_directory_uri().'/assets/css/confirm-presence.css', array('bootstrap', 'main'), '1.0', 'all');


    // wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Poppins:ital@0;1&display=swap', array(), null);
    wp_enqueue_script('bootstrap-bundle', get_template_directory_uri().'/assets/js/bootstrap.bundle.min.js', array(), '1.0', true);
    wp_enqueue_script('glider', get_template_directory_uri().'/assets/js/glider.min.js', array('bootstrap-bundle'), '1.0', true);
    wp_enqueue_script('phosphor-icons', get_template_directory_uri().'/assets/js/phosphor-icons.js', array('bootstrap-bundle'), '1.0', true);
    wp_enqueue_script('main', get_template_directory_uri().'/assets/js/main.js', array('bootstrap-bundle', 'glider'), '1.0', true);
    wp_register_script('confirm-presence', get_template_directory_uri().'/assets/js/classes/ConfirmPresence.js', array('bootstrap-bundle', 'jquery'), '1.0', true);
    wp_register_script('presence', get_template_directory_uri().'/assets/js/classes/Presence.js', array('bootstrap-bundle', 'jquery'), '1.0', true);
   
}


add_action('wp_enqueue_scripts', 'amille_party_load_scripts');

register_nav_menus(
    array(
        'amille_party_main_menu' => 'Menu Principal'
    )
);

function add_class_li($classes, $item, $args){
    if(isset($args->li_class)){
        $classes[] = $args->li_class;
    }
    if(isset($args->active_class) && in_array('current-menu-item', $classes)){
        $classes[] = $args->active_class;
    }

    return $classes;
}

add_filter('nav_menu_css_class', 'add_class_li', 10, 3);

function add_anchor_class($attr, $item, $args){
    if(isset($args->a_class)){
        $attr['class'] = $args->a_class;
    }
    return $attr;
}

add_filter('nav_menu_link_attributes', 'add_anchor_class', 10, 3);

add_action('wp_ajax_insert_guest', 'insert_guest');
add_action('wp_ajax_nopriv_insert_guest', 'insert_guest');

add_action('wp_ajax_layout_list_guests', 'layout_list_guests');
add_action('wp_ajax_nopriv_layout_list_guests', 'layout_list_guests');

add_action('wp_ajax_delete_list', 'delete_list');
add_action('wp_ajax_nopriv_delete_list', 'delete_list');

add_action('wp_ajax_send_email', 'send_email');
add_action('wp_ajax_nopriv_send_email', 'send_email');

function insert_guest(){

    $idList = $_POST['idList'];
    $resp = '';
    $guestMain = [];

    $arrayCategorys = [];

    foreach($_POST['obj'] as $key => $data){
        if($data['guestType'] == 'guest')
        {
            $guestMain = array(
                'ID' => $idList,
                'post_title'    => wp_strip_all_tags($data['name'].' '.$data['surname']),
                'post_status'   => 'publish',
                'post_type' => 'amille_guest_list',
            );

            $arrayCategorys = [$data['guestType'], $data['category']];
        }
    }
  
    $post_id = wp_insert_post( $guestMain );
    $arrayPostMeta = [];

    if($post_id){
        wp_set_object_terms($post_id, $arrayCategorys, 'category_list');

        foreach($_POST['obj'] as $key => $data){
            if($data['guestType'] != 'guest')
            {
                array_push($arrayPostMeta, $data);
            }
        }

        $resp = update_post_meta($post_id, 'guests', $arrayPostMeta);
    }

    if($resp){
        $msg = "Lista cadastrada com sucesso!";
        if($idList)
        {
            $msg = "Lista atualizada com sucesso!";
        }
        die_json_status_code(['msg' =>  $msg, 'idList' => $post_id], 200);
    }else{
        die_json_status_code(['msg' => 'Erro ao cadastrar lista!'], 404);
    }
}

function die_json_status_code(array $array, int $statusCode)
{
    header('Content-Type: application/json; charset=utf-8');
    http_response_code($statusCode);
    die(json_encode($array));
}

function layout_list_guests(){
    $postArray = [];
    $post = get_post( $_POST['idList']);
    if($post)
    {
        $categoryPost = get_the_terms($post->ID, 'category_list');
        $data = get_post_meta($_POST['idList'], 'guests', true);
    }else{
        die_json_status_code(['msg' => 'Erro ao consultar convidado'], 404);
    }

    $guestType =  '';
    $category =  '';

    if($categoryPost){
        foreach($categoryPost as $cat){
        
            if($cat->slug == 'adult' || $cat->slug == 'adolescent')
            {
                $category = $cat->slug;
            }else{
                $guestType = $cat->slug;
            }
        }
    }    

    $postArray = ['id' => $post->ID, 'name' => $post->post_title, 'surname' => '', 'guestType' => $guestType,'category' => $category];

    array_push($data, $postArray);
    
    return die_json_status_code($data, 200);
}

function delete_list(){
    $delete = wp_delete_post($_POST['idList'], true);
    if($delete){
        die_json_status_code(['msg' =>  'Lista deletada com sucesso!'], 200);
    }else{
        die_json_status_code(['msg' => 'Erro ao deletar lista!'], 404);
    }
}


 

// function send_email(){

//     $mail = new PHPMailer(true);

//     try {
//         $mail->SMTPDebug = SMTP::DEBUG_SERVER;
//         $mail->isSMTP();
//         $mail->Host = 'smtp.gmail.com';
//         $mail->SMTPAuth = true;
//         $mail->Username = 'matheus.e.arruda@gmail.com';
//         $mail->Password = 'lwjiwgmeclzrtowv';
//         $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
//         $mail->Port = 465;
     
//         $mail->setFrom('matheus.e.arruda@gmail.com', 'Matheus');
//         $mail->addAddress('amilleparty@gmail.com');
     
//         $mail->isHTML(true);
//         $mail->Subject = 'Teste de email via gmail Canal TI';
//         $mail->Body = 'Chegou o email teste do <strong>Canal TI</strong>';
//         $mail->AltBody = 'Chegou o email teste do Canal TI';

//         if($mail->send()) {
//             //echo 'Email enviado com sucesso';
//             die_json_status_code(['msg' =>  'Email enviado com sucesso'], 200);
//         } else {
//             //echo 'Email nao enviado';
//             die_json_status_code(['msg' => 'Email nao enviado'], 404);
//         }

//     } catch (Exception $e) {
//         //echo "Erro ao enviar mensagem: {$mail->ErrorInfo}";
//         die_json_status_code(['msg' => 'Erro'], 404);
//     }
// }
