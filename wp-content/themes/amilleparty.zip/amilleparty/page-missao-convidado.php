<?php get_header(); ?>
<section>
    <div class="bg-banner-guest-mission" style="background-image: url(<?= get_template_directory_uri().'/assets/img/2.png' ?>);">
        <h1>Missão Convidado</h1>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">

            </div>
            <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">
                <h1></h1>
                <p></p>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>