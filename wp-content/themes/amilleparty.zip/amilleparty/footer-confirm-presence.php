<footer>
</footer>
<?php wp_footer(); ?>
</body>
</html>