var head = document.getElementsByTagName("head")[0];
var link = document.createElement("link");
link.rel = "stylesheet";
link.type = "text/css";
link.href = "https://unpkg.com/phosphor-icons@1.4.2/src/css/icons.css";
head.appendChild(link);
