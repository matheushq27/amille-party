<footer class="amille-party-bg-primary">
    <div class="container">
        <div class="d-flex justify-content-center align-items-center pt-3 pb-3 text-center">
            <p class="m-0 fs-5 text-white">© 2023 Amille Party. Desenvolvido por <a href="#" id="whatsapp-link" class="text-secondary fw-bold">Onedev</a>.</p>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>